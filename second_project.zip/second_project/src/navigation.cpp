#include <ros/ros.h>
#include <move_base_msgs/MoveBaseAction.h>
#include <actionlib/client/simple_action_client.h>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include <tf2/LinearMath/Quaternion.h>

typedef actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction> MoveBaseClient;

class navigation {
      private:
            ros::NodeHandle n;
            move_base_msgs::MoveBaseGoal goal;

      public:
            navigation() {
            
            }

            void publishGoal() {
                  MoveBaseClient ac("move_base", true);
                  
                  while(!ac.waitForServer(ros::Duration(5.0))){
                        ROS_INFO("Waiting for the move_base action server to come up");
                  }
                  ROS_INFO("Sending goal");
                  std::string path;
                  n.getParam("waypoints", path);
                  std::ifstream data(path);
                  std::string line;

                  while( std::getline(data, line) ) {
                        std::stringstream lineStream(line);
                        std::string x;
                        double y;
                        std::getline( lineStream, x, ',' );
                        y = std::stod(x);
                        goal.target_pose.pose.position.x = y;
                        std::getline( lineStream, x, ',' );
                        y = std::stod(x);
                        goal.target_pose.pose.position.y = y;
                        goal.target_pose.pose.position.z = 0.0;
                        std::getline( lineStream, x, ',' );
                        y = std::stod(x);
                        goal.target_pose.header.frame_id = "map";
                        goal.target_pose.header.stamp = ros::Time::now();
                        goal.target_pose.pose.orientation.x = 0.0;
                        goal.target_pose.pose.orientation.y = 0.0;
                        goal.target_pose.pose.orientation.z = y;
                        std::getline( lineStream, x, ',' );
                        y = std::stod(x);
                        goal.target_pose.pose.orientation.w = y;

                        ac.sendGoal(goal);
   
                        ac.waitForResult();
                  }     

            }

   };
      

 
   int main(int argc, char** argv){
      ros::init(argc, argv, "navigation"); 
      navigation navigation;
      navigation.publishGoal();
      ros::spin();
   
     return 0;
   }

      