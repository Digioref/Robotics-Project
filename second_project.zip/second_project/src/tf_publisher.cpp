#include <ros/ros.h>
#include <std_msgs/String.h>
#include <nav_msgs/Odometry.h>
#include <tf/LinearMath/Quaternion.h>
#include <tf/transform_broadcaster.h>
#include <time.h>

class tf_publisher {
    private:
        ros::NodeHandle n;
		ros::Subscriber sub_odom;

		tf::TransformBroadcaster transform_broadcaster;
  		geometry_msgs::TransformStamped odomTransform;

        

    public:
        tf_publisher() {
            sub_odom = n.subscribe("/t265/odom", 1000, &tf_publisher::publishTFOdometry, this);
        }


        void publishTFOdometry(const nav_msgs::Odometry& msg) {

            odomTransform.header.stamp = ros::Time::now();
            odomTransform.header.frame_id = "odom";     
            odomTransform.child_frame_id = "t265";

            odomTransform.transform.translation.x = msg.pose.pose.position.x;
            odomTransform.transform.translation.y = msg.pose.pose.position.y;
            odomTransform.transform.translation.z = msg.pose.pose.position.z;

            odomTransform.transform.rotation.x = msg.pose.pose.orientation.x;
            odomTransform.transform.rotation.y = msg.pose.pose.orientation.y;
            odomTransform.transform.rotation.z = msg.pose.pose.orientation.z;
            odomTransform.transform.rotation.w = msg.pose.pose.orientation.w;

            transform_broadcaster.sendTransform(odomTransform);

        }    
}; 

int main(int argc, char **argv){

    ros::init(argc, argv, "tf_publisher");
    tf_publisher tf_publisher;
    ros::spin();
    return 0;
}    


