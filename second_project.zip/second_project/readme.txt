For mapping we decided to use slam toolbox instead of gmapping mainly for the ease of use.
We decided to clean the map a little for navigation even though we probably didn't need to. 
We also decided to move the robot's starting position to the bottom-left corner to make it easier to plan the path with the waypoints.
During mapping we used a node to publish the tf.

For localization we used amcl as written in the specifics.
For path planning we used the base global planner and teb local planner with clearing rotation.
To move the robot we used move_base and used our node as an action client to publish the goals.

For the navigation node we decided to read 4 variables from the csv file x and y for the position and z and w of a quaternion for the heading. (We could have easily used radiants then convert them in a quaternion but we preferred to use the quaternion values directly).

To load the waypoints.csv file, we used "getParam" in the node navigation to get the path of the file, which is set in the launch file as a parameter, and then the file is opened using ifstream.