#include "ros/ros.h"
#include "std_msgs/String.h"
#include <nav_msgs/Odometry.h>
#include <tf/LinearMath/Quaternion.h>
#include <tf/transform_broadcaster.h>
#include "first_project/Odom.h"
#include "first_project/reset_odom.h"
#include <time.h>
#include <sstream>
#include <cmath>
#include <cstring>

class odom_node {
    private:
        ros::NodeHandle n;
		ros::Subscriber sub_odom;
		ros::Publisher pub_odom; 
		ros::Publisher pub_custom; 

		
		double starting_x;
		double starting_y;
		double starting_th;
		ros::Time t_prev;

		tf::TransformBroadcaster transform_broadcaster;
  		geometry_msgs::TransformStamped odomTransform;

		ros::ServiceServer reset_service;
        

    public:
        odom_node() {
            
            n.getParam("/starting/x", starting_x);
            n.getParam("/starting/y", starting_y);
            n.getParam("/starting/th", starting_th);

            sub_odom = n.subscribe("speed_steer", 1000, &odom_node::calculate_odometry, this);
            pub_odom = n.advertise<nav_msgs::Odometry>("odometry", 1000);
            pub_custom = n.advertise<first_project::Odom>("custom_odometry", 1000);

            reset_service = n.advertiseService("reset_odom", &odom_node::reset_odom, this);
        }

        void calculate_odometry(const geometry_msgs::QuaternionConstPtr& msg) {
            
            double x_next, y_next, theta_next, delta_t, angular_velocity;
            ros::Time current_time = ros::Time::now();

            while (t_prev.toSec() == 0) {
                t_prev = ros::Time::now();    
            }
        
			delta_t = (double) ((current_time - t_prev).toSec());
            
            angular_velocity = msg->x * (tan(msg->y) / 2.8);

			x_next = starting_x + (msg->x  * delta_t * std::cos(starting_th + ((angular_velocity * delta_t) / 2.0)));
			y_next = starting_y + (msg->x  * delta_t * std::sin(starting_th + ((angular_velocity * delta_t) / 2.0)));
			
			theta_next = starting_th + (angular_velocity * delta_t);
            
            publishTFOdometry(x_next, y_next, theta_next, current_time);
            publishOdometry(x_next, y_next, theta_next, (msg->x) * cos(starting_th), (msg->x) * sin(starting_th), angular_velocity, current_time);

            t_prev = current_time;
            starting_x = x_next;
            starting_y = y_next;
            starting_th = theta_next;
        }

        void publishTFOdometry(double x, double y, double theta, ros::Time time) {

            odomTransform.header.stamp = time;
            odomTransform.header.frame_id = "odom";
            odomTransform.child_frame_id = "base_link";

            odomTransform.transform.translation.x = x;
            odomTransform.transform.translation.y = y;
            odomTransform.transform.translation.z = 0.0;

            tf::Quaternion q;
            q.setRPY(0, 0, theta);

            odomTransform.transform.rotation.x = q.x();
            odomTransform.transform.rotation.y = q.y();
            odomTransform.transform.rotation.z = q.z();
            odomTransform.transform.rotation.w = q.w();

            transform_broadcaster.sendTransform(odomTransform);

        }    

        void publishOdometry(double x, double y, double theta, double vx, double vy, double omega, ros::Time time) {

            first_project::Odom custom_msg;
			nav_msgs::Odometry nav_msg;
            double t = (double) time.toSec();

            custom_msg.x = x;
            custom_msg.y = y;
            custom_msg.th = theta;
            custom_msg.timestamp = std::__cxx11::to_string(t);

            nav_msg.header.stamp = time;
            nav_msg.header.frame_id = "odom";

            nav_msg.child_frame_id = "base_link";
            nav_msg.pose.pose.position.x = x;
			nav_msg.pose.pose.position.y = y;
			nav_msg.pose.pose.position.z = 0.0;

            tf::Quaternion q;
            q.setRPY(0, 0, theta);

            nav_msg.pose.pose.orientation.x = q.x();
			nav_msg.pose.pose.orientation.y = q.y();
			nav_msg.pose.pose.orientation.z = q.z();
            nav_msg.pose.pose.orientation.w = q.w();

            nav_msg.twist.twist.linear.x = vx;
            nav_msg.twist.twist.linear.y = vy;
            nav_msg.twist.twist.linear.z = 0.0;
            nav_msg.twist.twist.angular.x = 0.0;
            nav_msg.twist.twist.angular.y = 0.0;
            nav_msg.twist.twist.angular.z = omega;

            pub_odom.publish(nav_msg);
            pub_custom.publish(custom_msg);
 
        }

        bool reset_odom(first_project::reset_odom::Request  &req, first_project::reset_odom::Response &res) {
            starting_x = 0.0;
            starting_y = 0.0;
            starting_th = 0.0;

            while (t_prev.toSec() == 0) {
                t_prev = ros::Time::now();    
            }
            
            res.resetted = true;
            
            return true;

        }

};

int main(int argc, char **argv){

    ros::init(argc, argv, "odom_node");
    odom_node odom_node;
    ros::spin();
    return 0;
}    